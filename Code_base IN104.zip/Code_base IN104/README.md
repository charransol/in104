to launch the code : 

```commandline
$ usensta python3  
```
```commandline
$ python main.py 
```


To install gym : 

```commandline
$ pip install --user gym
```